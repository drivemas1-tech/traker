import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertUserGameSchema } from "@shared/schema";
import bcrypt from "bcrypt";
import { getSteamApps, getSteamCoverUrl } from "./steam-api";

declare module "express-session" {
  interface SessionData {
    userId: string;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  const requireAuth = (req: Request, res: Response, next: Function) => {
    if (!req.session.userId) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    next();
  };

  // Get current user
  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const user = await storage.getUser(req.session.userId);
    if (!user) {
      req.session.userId = undefined;
      return res.status(401).json({ error: "User not found" });
    }

    res.json({ id: user.id, username: user.username });
  });

  // Register
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { username, password } = insertUserSchema.parse(req.body);

      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ error: "Username already exists" });
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      const user = await storage.createUser({ username, password: hashedPassword });

      req.session.userId = user.id;
      res.json({ id: user.id, username: user.username });
    } catch (error) {
      res.status(400).json({ error: "Invalid request" });
    }
  });

  // Login
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = insertUserSchema.parse(req.body);

      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      req.session.userId = user.id;
      res.json({ id: user.id, username: user.username });
    } catch (error) {
      res.status(400).json({ error: "Invalid request" });
    }
  });

  // Logout
  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Failed to logout" });
      }
      res.json({ success: true });
    });
  });

  // Get Steam games catalog
  app.get("/api/steam/games", async (req, res) => {
    try {
      const search = (req.query.search as string) || "";
      const limit = parseInt(req.query.limit as string) || 100;
      
      const allApps = await getSteamApps();
      
      let filteredApps = allApps;
      if (search) {
        const searchLower = search.toLowerCase();
        filteredApps = allApps.filter(app => 
          app.name.toLowerCase().includes(searchLower)
        );
      }

      // Return limited results with cover URLs
      const results = filteredApps.slice(0, limit).map(app => ({
        id: app.appid,
        name: app.name,
        coverUrl: getSteamCoverUrl(app.appid),
      }));

      res.json(results);
    } catch (error) {
      console.error("Error fetching Steam games:", error);
      res.status(500).json({ error: "Failed to fetch games" });
    }
  });

  // Get user's games
  app.get("/api/user/games", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const userGames = await storage.getUserGames(userId);

      // Fetch full game info from Steam
      const allApps = await getSteamApps();
      const gamesWithInfo = userGames.map(ug => {
        const steamApp = allApps.find(app => app.appid === ug.steamAppId);
        return {
          id: ug.id,
          steamAppId: ug.steamAppId,
          name: steamApp?.name || "Unknown Game",
          coverUrl: getSteamCoverUrl(ug.steamAppId),
          status: ug.status,
        };
      });

      res.json(gamesWithInfo);
    } catch (error) {
      console.error("Error fetching user games:", error);
      res.status(500).json({ error: "Failed to fetch games" });
    }
  });

  // Add game to user's library
  app.post("/api/user/games", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const gameData = insertUserGameSchema.parse(req.body);

      const userGame = await storage.addUserGame(userId, gameData);
      res.json(userGame);
    } catch (error) {
      console.error("Error adding game:", error);
      res.status(400).json({ error: "Invalid request" });
    }
  });

  // Update game status
  app.patch("/api/user/games/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;

      const updated = await storage.updateUserGame(id, status);
      if (!updated) {
        return res.status(404).json({ error: "Game not found" });
      }

      res.json(updated);
    } catch (error) {
      res.status(400).json({ error: "Invalid request" });
    }
  });

  // Delete game from library
  app.delete("/api/user/games/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteUserGame(id);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ error: "Invalid request" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
