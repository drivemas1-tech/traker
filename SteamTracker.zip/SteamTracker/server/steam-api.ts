interface SteamApp {
  appid: number;
  name: string;
}

interface SteamAppListResponse {
  applist: {
    apps: SteamApp[];
  };
}

let cachedApps: SteamApp[] | null = null;
let lastFetchTime = 0;
const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours

export async function getSteamApps(): Promise<SteamApp[]> {
  const now = Date.now();
  
  // Return cached data if available and fresh
  if (cachedApps && (now - lastFetchTime) < CACHE_DURATION) {
    return cachedApps;
  }

  try {
    const response = await fetch(
      "https://api.steampowered.com/ISteamApps/GetAppList/v2/"
    );
    
    if (!response.ok) {
      throw new Error(`Steam API responded with status: ${response.status}`);
    }

    const data: SteamAppListResponse = await response.json();
    cachedApps = data.applist.apps.filter(app => app.name && app.name.trim() !== "");
    lastFetchTime = now;
    
    return cachedApps;
  } catch (error) {
    console.error("Failed to fetch Steam apps:", error);
    
    // Return cached data even if expired, or empty array
    return cachedApps || [];
  }
}

export function getSteamCoverUrl(appId: number): string {
  // Steam's library capsule art (portrait format, 2:3 ratio)
  return `https://cdn.cloudflare.steamstatic.com/steam/apps/${appId}/library_600x900_2x.jpg`;
}

export function getSteamHeaderUrl(appId: number): string {
  // Alternative: landscape header (460x215)
  return `https://cdn.akamai.steamstatic.com/steam/apps/${appId}/header.jpg`;
}
