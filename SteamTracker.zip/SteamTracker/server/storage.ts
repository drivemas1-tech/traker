import { type User, type InsertUser, type UserGame, type InsertUserGame } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUserGames(userId: string): Promise<UserGame[]>;
  addUserGame(userId: string, game: InsertUserGame): Promise<UserGame>;
  updateUserGame(id: string, status: string): Promise<UserGame | undefined>;
  deleteUserGame(id: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private userGames: Map<string, UserGame>;

  constructor() {
    this.users = new Map();
    this.userGames = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getUserGames(userId: string): Promise<UserGame[]> {
    return Array.from(this.userGames.values()).filter(
      (game) => game.userId === userId
    );
  }

  async addUserGame(userId: string, game: InsertUserGame): Promise<UserGame> {
    const id = randomUUID();
    const userGame: UserGame = { ...game, id, userId };
    this.userGames.set(id, userGame);
    return userGame;
  }

  async updateUserGame(id: string, status: string): Promise<UserGame | undefined> {
    const game = this.userGames.get(id);
    if (game) {
      const updated = { ...game, status };
      this.userGames.set(id, updated);
      return updated;
    }
    return undefined;
  }

  async deleteUserGame(id: string): Promise<void> {
    this.userGames.delete(id);
  }
}

export const storage = new MemStorage();
