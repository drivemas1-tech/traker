# Design Guidelines: Steam Game Tracker

## Design Approach

**Reference-Based with Gaming Aesthetic**: Drawing inspiration from Steam, Epic Games Store, and Xbox Game Pass interfaces, emphasizing game cover art visibility, dark gaming UI conventions, and efficient library management patterns.

## Core Design Elements

### A. Color Palette

**Dark Mode Primary Colors:**
- Background: 210 15% 16% (soft grey-dark blue as specified)
- Surface: 210 15% 20% (slightly lighter cards/panels)
- Surface Elevated: 210 15% 24% (hover states, elevated elements)
- Border: 210 12% 30% (subtle separation)
- Text Primary: 0 0% 100% (white as specified)
- Text Secondary: 210 10% 70% (muted white for metadata)
- Accent Primary: 210 80% 55% (Steam-inspired blue for CTAs)
- Accent Hover: 210 80% 60%
- Success: 142 76% 45% (for "All Achievements" status)
- Warning: 45 93% 58% (for "Playing" status)
- Info: 217 91% 60% (for "To Be Played" status)
- Neutral: 210 10% 50% (for "Played" status)

### B. Typography

**Font Stack:**
- Primary: 'Inter' or 'Segoe UI' via Google Fonts - clean, modern sans-serif
- Headings: Semi-bold (600) for profile names, category headers
- Body: Regular (400) for game titles, descriptions
- Stats: Bold (700) for numerical counts

**Hierarchy:**
- Page Title (Username): text-3xl md:text-4xl font-semibold
- Category Headers: text-xl md:text-2xl font-semibold
- Game Counts/Stats: text-4xl md:text-5xl font-bold
- Game Titles: text-sm md:text-base font-medium
- Form Labels: text-sm font-medium
- Metadata: text-xs md:text-sm text-secondary

### C. Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16, and 24 for consistent rhythm.
- Component padding: p-4 to p-6
- Section spacing: gap-8 to gap-12
- Page margins: px-4 md:px-8 lg:px-16

**Grid System:**
- Game grid: grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 (responsive game cover display)
- Stats grid: grid-cols-2 md:grid-cols-4 (for category counts)
- Max container width: max-w-7xl mx-auto

### D. Component Library

**Authentication Pages (Login/Registration):**
- Centered card design (max-w-md) on full-viewport background
- Form inputs: Dark surface with lighter border, white text, focus state with accent border
- Primary button: Full accent color with hover state
- Input fields: p-3, rounded-lg, border-2 transition

**Game Browser Interface:**
- Header with search/filter bar (sticky positioning)
- Game cards in responsive grid layout
- Card design: Game cover image (16:9 aspect ratio), overlay with game title on hover, status badge in top-right corner
- Card interaction: Subtle scale on hover (hover:scale-105 transition)

**Profile Dashboard:**
- Header section: Large username display with subtle decorative element
- Stats section: 4-column grid showing count for each category with icons and labels
- Category sections: Each status category as collapsible/expandable section with game grid underneath
- Empty states: Friendly messaging for categories with no games

**Game Cards:**
- Cover image: Full width, aspect-video, object-cover
- Status badge: Absolute positioned, top-2 right-2, rounded-full px-3 py-1, category-specific color
- Title overlay: Dark gradient overlay at bottom with white text
- Interactive states: Smooth hover effects, cursor-pointer

**Navigation:**
- Top navigation bar: Logo/app name, user profile dropdown/logout
- Sticky positioning on scroll
- Height: h-16, backdrop-blur for depth

**Status Badges:**
- Played: Neutral gray background
- All Achievements: Success green background with trophy icon
- To Be Played: Info blue background with bookmark icon
- Playing: Warning yellow/amber background with controller icon

### E. Animations

**Minimal, purposeful animations:**
- Card hover: transform scale-105, duration-200
- Button interactions: subtle brightness shift on hover
- Page transitions: Simple fade-in for content sections
- Loading states: Subtle skeleton loaders for game cards

## Component Specifications

**Game Card Dimensions:**
- Standard Steam cover aspect ratio: aspect-[460/215] or aspect-video
- Minimum card width: 180px, maximum 280px
- Border radius: rounded-lg
- Shadow on hover: shadow-xl

**Form Components:**
- Input height: h-12
- Button height: h-12
- Border radius: rounded-lg
- Focus ring: ring-2 ring-accent

**Spacing Between Sections:**
- Profile stats to first category: space-y-12
- Between categories: space-y-8
- Within category (header to grid): space-y-4

## Images

**Game Covers:** Fetched from Steam API, displayed prominently in all game cards
**Profile Avatars:** Optional user avatar/icon in navigation (can use initial letter in colored circle as default)
**Empty State Illustrations:** Simple iconography for empty categories (e.g., game controller outline)

**Note:** No large hero image needed - this is a utility application focused on game library management rather than marketing.