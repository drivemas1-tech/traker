import { Card, CardContent } from "@/components/ui/card";
import { Trophy, Gamepad2, Bookmark, Check } from "lucide-react";

interface ProfileStatsProps {
  playedCount: number;
  achievementsCount: number;
  toPlayCount: number;
  playingCount: number;
}

export function ProfileStats({
  playedCount,
  achievementsCount,
  toPlayCount,
  playingCount,
}: ProfileStatsProps) {
  const stats = [
    {
      label: "Played",
      count: playedCount,
      icon: Check,
      color: "text-status-played",
    },
    {
      label: "All Achievements",
      count: achievementsCount,
      icon: Trophy,
      color: "text-status-achievements",
    },
    {
      label: "To Be Played",
      count: toPlayCount,
      icon: Bookmark,
      color: "text-status-to-play",
    },
    {
      label: "Playing",
      count: playingCount,
      icon: Gamepad2,
      color: "text-status-playing",
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {stats.map((stat) => {
        const Icon = stat.icon;
        return (
          <Card key={stat.label} data-testid={`card-stat-${stat.label.toLowerCase().replace(/\s+/g, "-")}`}>
            <CardContent className="p-6 flex flex-col items-center text-center space-y-2">
              <Icon className={`w-6 h-6 ${stat.color}`} />
              <div className="text-4xl md:text-5xl font-bold" data-testid={`text-count-${stat.label.toLowerCase().replace(/\s+/g, "-")}`}>
                {stat.count}
              </div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
