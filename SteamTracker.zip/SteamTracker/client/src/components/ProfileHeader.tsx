import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";

interface ProfileHeaderProps {
  username: string;
  onLogout: () => void;
}

export function ProfileHeader({ username, onLogout }: ProfileHeaderProps) {
  const initials = username
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-4">
        <Avatar className="w-16 h-16 md:w-20 md:h-20">
          <AvatarFallback className="text-xl md:text-2xl font-semibold bg-primary/10 text-primary">
            {initials}
          </AvatarFallback>
        </Avatar>
        <div>
          <h1 className="text-3xl md:text-4xl font-semibold" data-testid="text-username">
            {username}
          </h1>
          <p className="text-sm text-muted-foreground">Game Collection</p>
        </div>
      </div>
      <Button
        variant="outline"
        onClick={onLogout}
        data-testid="button-logout"
      >
        <LogOut className="w-4 h-4 mr-2" />
        Logout
      </Button>
    </div>
  );
}
