import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Search, Loader2 } from "lucide-react";
import { GameCard, type GameStatus } from "./GameCard";
import { GameStatusDialog } from "./GameStatusDialog";
import { useQuery } from "@tanstack/react-query";

interface Game {
  id: number;
  name: string;
  coverUrl: string;
}

interface GameBrowserProps {
  onAddGame: (gameId: number, status: GameStatus) => void;
}

export function GameBrowser({ onAddGame }: GameBrowserProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  // Debounce search query
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(searchQuery);
    }, 500);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Fetch games based on search
  const { data: games = [], isLoading } = useQuery<Game[]>({
    queryKey: ["/api/steam/games", { search: debouncedSearch, limit: 100 }],
    queryFn: async () => {
      const params = new URLSearchParams({
        search: debouncedSearch,
        limit: "100",
      });
      const res = await fetch(`/api/steam/games?${params}`, {
        credentials: "include",
      });
      
      if (!res.ok) {
        throw new Error(`${res.status}: ${res.statusText}`);
      }
      
      return await res.json();
    },
  });

  const handleGameClick = (game: Game) => {
    setSelectedGame(game);
    setDialogOpen(true);
  };

  const handleStatusSelect = (status: GameStatus) => {
    if (selectedGame) {
      onAddGame(selectedGame.id, status);
    }
  };

  return (
    <div className="space-y-6">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          data-testid="input-search"
          placeholder="Search Steam games..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {games.map((game) => (
              <GameCard
                key={game.id}
                id={game.id}
                name={game.name}
                coverUrl={game.coverUrl}
                onClick={() => handleGameClick(game)}
              />
            ))}
          </div>

          {games.length === 0 && !isLoading && (
            <div className="text-center py-12">
              <p className="text-muted-foreground" data-testid="text-no-results">
                {searchQuery ? `No games found matching "${searchQuery}"` : "Start typing to search for games"}
              </p>
            </div>
          )}
        </>
      )}

      {selectedGame && (
        <GameStatusDialog
          open={dialogOpen}
          onOpenChange={setDialogOpen}
          gameName={selectedGame.name}
          onStatusSelect={handleStatusSelect}
        />
      )}
    </div>
  );
}
