import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Trophy, Gamepad2, Bookmark, Check } from "lucide-react";
import type { GameStatus } from "./GameCard";

interface GameStatusDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  gameName: string;
  currentStatus?: GameStatus;
  onStatusSelect: (status: GameStatus) => void;
}

const statusOptions = [
  {
    value: "played" as GameStatus,
    label: "Played",
    icon: Check,
    description: "You've finished this game",
  },
  {
    value: "achievements" as GameStatus,
    label: "All Achievements",
    icon: Trophy,
    description: "You've unlocked all achievements",
  },
  {
    value: "to-play" as GameStatus,
    label: "To Be Played",
    icon: Bookmark,
    description: "You plan to play this game",
  },
  {
    value: "playing" as GameStatus,
    label: "Playing",
    icon: Gamepad2,
    description: "You're currently playing this game",
  },
];

export function GameStatusDialog({
  open,
  onOpenChange,
  gameName,
  currentStatus,
  onStatusSelect,
}: GameStatusDialogProps) {
  const [selectedStatus, setSelectedStatus] = useState<GameStatus | undefined>(
    currentStatus
  );

  const handleSelect = (status: GameStatus) => {
    setSelectedStatus(status);
    onStatusSelect(status);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent data-testid="dialog-game-status">
        <DialogHeader>
          <DialogTitle>Set Game Status</DialogTitle>
          <DialogDescription>
            Choose a status for <strong>{gameName}</strong>
          </DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
          {statusOptions.map((option) => {
            const Icon = option.icon;
            const isSelected = selectedStatus === option.value;
            return (
              <Button
                key={option.value}
                variant={isSelected ? "default" : "outline"}
                className="h-auto p-4 flex flex-col items-start gap-2"
                onClick={() => handleSelect(option.value)}
                data-testid={`button-status-${option.value}`}
              >
                <div className="flex items-center gap-2 w-full">
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{option.label}</span>
                </div>
                <span className="text-xs opacity-80 text-left">
                  {option.description}
                </span>
              </Button>
            );
          })}
        </div>
      </DialogContent>
    </Dialog>
  );
}
