import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Gamepad2, Bookmark, Check } from "lucide-react";

export type GameStatus = "played" | "achievements" | "to-play" | "playing";

interface GameCardProps {
  id: number;
  name: string;
  coverUrl: string;
  status?: GameStatus;
  onStatusChange?: (status: GameStatus) => void;
  onClick?: () => void;
}

const statusConfig = {
  played: {
    label: "Played",
    icon: Check,
    className: "bg-status-played text-status-played-foreground",
  },
  achievements: {
    label: "All Achievements",
    icon: Trophy,
    className: "bg-status-achievements text-status-achievements-foreground",
  },
  "to-play": {
    label: "To Be Played",
    icon: Bookmark,
    className: "bg-status-to-play text-status-to-play-foreground",
  },
  playing: {
    label: "Playing",
    icon: Gamepad2,
    className: "bg-status-playing text-status-playing-foreground",
  },
};

export function GameCard({ name, coverUrl, status, onClick }: GameCardProps) {
  const StatusIcon = status ? statusConfig[status].icon : null;

  return (
    <Card
      className="overflow-hidden hover-elevate active-elevate-2 cursor-pointer transition-transform hover:scale-105 duration-200"
      onClick={onClick}
      data-testid={`card-game-${name.toLowerCase().replace(/\s+/g, "-")}`}
    >
      <div className="relative aspect-[2/3]">
        <img
          src={coverUrl}
          alt={name}
          className="w-full h-full object-cover"
          onError={(e) => {
            // Fallback to a placeholder if image fails to load
            e.currentTarget.src = `https://via.placeholder.com/300x450/1a1a2e/ffffff?text=${encodeURIComponent(name)}`;
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
        {status && (
          <Badge
            className={`absolute top-2 right-2 flex items-center gap-1 ${statusConfig[status].className}`}
            data-testid={`badge-status-${status}`}
          >
            {StatusIcon && <StatusIcon className="w-3 h-3" />}
            {statusConfig[status].label}
          </Badge>
        )}
        <div className="absolute bottom-0 left-0 right-0 p-3">
          <h3 className="text-sm md:text-base font-medium text-white line-clamp-2">
            {name}
          </h3>
        </div>
      </div>
    </Card>
  );
}
