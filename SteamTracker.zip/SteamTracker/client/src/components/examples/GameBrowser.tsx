import { GameBrowser } from "../GameBrowser";

export default function GameBrowserExample() {
  return (
    <div className="p-6 max-w-7xl">
      <GameBrowser
        onAddGame={(gameId, status) => {
          console.log("Game added:", { gameId, status });
        }}
      />
    </div>
  );
}
