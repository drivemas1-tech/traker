import { useState } from "react";
import { Navigation } from "../Navigation";

export default function NavigationExample() {
  const [activeView, setActiveView] = useState<"profile" | "browse">("profile");

  return (
    <div>
      <Navigation activeView={activeView} onViewChange={setActiveView} />
      <div className="p-6">
        <p className="text-muted-foreground">
          Current view: <strong>{activeView}</strong>
        </p>
      </div>
    </div>
  );
}
