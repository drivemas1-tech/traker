import { GameCard } from "../GameCard";

export default function GameCardExample() {
  return (
    <div className="p-6 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-w-6xl">
      <GameCard
        id={1}
        name="Cyberpunk 2077"
        coverUrl="https://images.unsplash.com/photo-1542751371-adc38448a05e?w=460&h=215&fit=crop"
        status="playing"
        onClick={() => console.log("Game clicked")}
      />
      <GameCard
        id={2}
        name="The Witcher 3: Wild Hunt"
        coverUrl="https://images.unsplash.com/photo-1511512578047-dfb367046420?w=460&h=215&fit=crop"
        status="achievements"
        onClick={() => console.log("Game clicked")}
      />
      <GameCard
        id={3}
        name="Red Dead Redemption 2"
        coverUrl="https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=460&h=215&fit=crop"
        status="played"
        onClick={() => console.log("Game clicked")}
      />
      <GameCard
        id={4}
        name="Elden Ring"
        coverUrl="https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=460&h=215&fit=crop"
        status="to-play"
        onClick={() => console.log("Game clicked")}
      />
    </div>
  );
}
