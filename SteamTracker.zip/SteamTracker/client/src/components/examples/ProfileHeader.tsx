import { ProfileHeader } from "../ProfileHeader";

export default function ProfileHeaderExample() {
  return (
    <div className="p-6">
      <ProfileHeader
        username="GamerPro2024"
        onLogout={() => console.log("Logout clicked")}
      />
    </div>
  );
}
