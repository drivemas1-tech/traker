import { useState } from "react";
import { GameStatusDialog } from "../GameStatusDialog";
import { Button } from "@/components/ui/button";
import type { GameStatus } from "../GameCard";

export default function GameStatusDialogExample() {
  const [open, setOpen] = useState(false);
  const [status, setStatus] = useState<GameStatus | undefined>("playing");

  return (
    <div className="p-6 flex flex-col items-center gap-4">
      <Button onClick={() => setOpen(true)} data-testid="button-open-dialog">
        Open Status Dialog
      </Button>
      <p className="text-sm text-muted-foreground">
        Current status: <strong>{status || "None"}</strong>
      </p>
      <GameStatusDialog
        open={open}
        onOpenChange={setOpen}
        gameName="Cyberpunk 2077"
        currentStatus={status}
        onStatusSelect={(newStatus) => {
          setStatus(newStatus);
          console.log("Status selected:", newStatus);
        }}
      />
    </div>
  );
}
