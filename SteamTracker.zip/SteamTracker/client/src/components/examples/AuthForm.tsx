import { useState } from "react";
import { AuthForm } from "../AuthForm";

export default function AuthFormExample() {
  const [mode, setMode] = useState<"login" | "register">("login");

  return (
    <AuthForm
      mode={mode}
      onSubmit={(username, password) => {
        console.log("Auth submitted:", { username, password, mode });
      }}
      onToggleMode={() => setMode(mode === "login" ? "register" : "login")}
    />
  );
}
