import { ProfileStats } from "../ProfileStats";

export default function ProfileStatsExample() {
  return (
    <div className="p-6 max-w-6xl">
      <ProfileStats
        playedCount={42}
        achievementsCount={15}
        toPlayCount={28}
        playingCount={5}
      />
    </div>
  );
}
