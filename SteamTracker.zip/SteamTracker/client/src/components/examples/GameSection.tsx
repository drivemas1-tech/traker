import { GameSection } from "../GameSection";

const mockGames = [
  { id: 1, name: "Cyberpunk 2077", coverUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=460&h=215&fit=crop", status: "playing" as const },
  { id: 2, name: "The Witcher 3", coverUrl: "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=460&h=215&fit=crop", status: "playing" as const },
  { id: 3, name: "Red Dead Redemption 2", coverUrl: "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=460&h=215&fit=crop", status: "playing" as const },
];

export default function GameSectionExample() {
  return (
    <div className="p-6 space-y-8 max-w-7xl">
      <GameSection title="Playing" games={mockGames} />
    </div>
  );
}
