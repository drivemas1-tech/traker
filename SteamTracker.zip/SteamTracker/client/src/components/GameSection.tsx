import { GameCard, type GameStatus } from "./GameCard";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { ChevronDown, ChevronUp } from "lucide-react";
import { useState } from "react";

interface Game {
  id: number;
  name: string;
  coverUrl: string;
  status: GameStatus;
}

interface GameSectionProps {
  title: string;
  games: Game[];
  defaultOpen?: boolean;
}

export function GameSection({ title, games, defaultOpen = true }: GameSectionProps) {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  if (games.length === 0) {
    return null;
  }

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen} className="space-y-4">
      <CollapsibleTrigger
        className="flex items-center justify-between w-full hover-elevate active-elevate-2 p-4 rounded-lg"
        data-testid={`button-toggle-${title.toLowerCase().replace(/\s+/g, "-")}`}
      >
        <h2 className="text-xl md:text-2xl font-semibold">{title}</h2>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">
            {games.length} {games.length === 1 ? "game" : "games"}
          </span>
          {isOpen ? (
            <ChevronUp className="w-5 h-5" />
          ) : (
            <ChevronDown className="w-5 h-5" />
          )}
        </div>
      </CollapsibleTrigger>
      <CollapsibleContent>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {games.map((game) => (
            <GameCard
              key={game.id}
              id={game.id}
              name={game.name}
              coverUrl={game.coverUrl}
              status={game.status}
              onClick={() => console.log("Game clicked:", game.name)}
            />
          ))}
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}
