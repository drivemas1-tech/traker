import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ProfileHeader } from "@/components/ProfileHeader";
import { ProfileStats } from "@/components/ProfileStats";
import { GameSection } from "@/components/GameSection";
import { Navigation } from "@/components/Navigation";
import { GameBrowser } from "@/components/GameBrowser";
import { useAuth } from "@/lib/auth-context";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { GameStatus } from "@/components/GameCard";

interface SteamGame {
  id: number;
  name: string;
  coverUrl: string;
}

interface UserGame {
  id: string;
  steamAppId: number;
  name: string;
  coverUrl: string;
  status: GameStatus;
}

export default function ProfilePage() {
  const { user, logout, isLoading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [activeView, setActiveView] = useState<"profile" | "browse">("profile");
  const [searchQuery, setSearchQuery] = useState("");

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !user) {
      setLocation("/");
    }
  }, [user, authLoading, setLocation]);


  // Fetch user's games
  const { data: userGames = [] } = useQuery<UserGame[]>({
    queryKey: ["/api/user/games"],
    enabled: !!user,
  });

  // Add game mutation
  const addGameMutation = useMutation({
    mutationFn: async ({ steamAppId, status }: { steamAppId: number; status: GameStatus }) => {
      const res = await apiRequest("POST", "/api/user/games", { steamAppId, status });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/games"] });
      setActiveView("profile");
      toast({
        title: "Game added",
        description: "The game has been added to your library",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add game",
        variant: "destructive",
      });
    },
  });

  const handleLogout = async () => {
    try {
      await logout();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to logout",
        variant: "destructive",
      });
    }
  };

  const handleAddGame = (gameId: number, status: GameStatus) => {
    // Check if game already exists
    const exists = userGames.find((g) => g.steamAppId === gameId);
    if (exists) {
      toast({
        title: "Game already in library",
        description: "This game is already in your collection",
        variant: "destructive",
      });
      return;
    }
    
    addGameMutation.mutate({ steamAppId: gameId, status });
  };

  if (authLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    );
  }

  const playedGames = userGames.filter((g) => g.status === "played");
  const achievementGames = userGames.filter((g) => g.status === "achievements");
  const toPlayGames = userGames.filter((g) => g.status === "to-play");
  const playingGames = userGames.filter((g) => g.status === "playing");

  return (
    <div className="min-h-screen">
      <Navigation activeView={activeView} onViewChange={setActiveView} />
      
      <main className="max-w-7xl mx-auto px-4 md:px-8 py-8">
        {activeView === "profile" ? (
          <div className="space-y-12">
            <ProfileHeader username={user.username} onLogout={handleLogout} />
            
            <ProfileStats
              playedCount={playedGames.length}
              achievementsCount={achievementGames.length}
              toPlayCount={toPlayGames.length}
              playingCount={playingGames.length}
            />

            <div className="space-y-8">
              <GameSection 
                title="Playing" 
                games={playingGames.map(g => ({ 
                  id: g.steamAppId, 
                  name: g.name, 
                  coverUrl: g.coverUrl, 
                  status: g.status 
                }))} 
              />
              <GameSection 
                title="All Achievements" 
                games={achievementGames.map(g => ({ 
                  id: g.steamAppId, 
                  name: g.name, 
                  coverUrl: g.coverUrl, 
                  status: g.status 
                }))} 
              />
              <GameSection 
                title="Played" 
                games={playedGames.map(g => ({ 
                  id: g.steamAppId, 
                  name: g.name, 
                  coverUrl: g.coverUrl, 
                  status: g.status 
                }))} 
              />
              <GameSection 
                title="To Be Played" 
                games={toPlayGames.map(g => ({ 
                  id: g.steamAppId, 
                  name: g.name, 
                  coverUrl: g.coverUrl, 
                  status: g.status 
                }))} 
              />
            </div>

            {userGames.length === 0 && (
              <div className="text-center py-12">
                <p className="text-muted-foreground text-lg" data-testid="text-empty-library">
                  Your library is empty. Add some games to get started!
                </p>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl md:text-4xl font-semibold mb-2">Browse Games</h1>
              <p className="text-muted-foreground">
                Search and add games from the Steam catalog
              </p>
            </div>
            <GameBrowser onAddGame={handleAddGame} />
          </div>
        )}
      </main>
    </div>
  );
}
